# This submission hacks 207028922

print("3")
print("1 1 1")
