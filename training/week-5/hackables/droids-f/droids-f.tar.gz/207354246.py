# This submission hacks 207354246

print("3")
print("1 1 1")
