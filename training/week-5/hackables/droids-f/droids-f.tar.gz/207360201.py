# This submission hacks 207360201

print("3")
print("1 1 1")
