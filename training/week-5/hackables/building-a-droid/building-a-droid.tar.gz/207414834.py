# This submission hacks 207414834

print("11 54157302423 86229311176 83826105235 94580055194 83826105235")
print("187")
print("170")
print("106")
print("19")
print("131")
print("84")
print("141")
print("183")
print("153")
print("53")
print("10")
