# This submission hacks 208240950

print("1")
print("2")
print("00")
