# This submission hacks 207945399

print("1")
print("1")
print("1")
