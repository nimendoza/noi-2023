# This submission hacks 207149431

print("1")
print("1 269")
print("15")
