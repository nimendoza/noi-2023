# This submission hacks 207153090

print("1")
print("1 269")
print("15")
