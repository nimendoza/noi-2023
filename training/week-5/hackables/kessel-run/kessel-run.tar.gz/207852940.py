# This submission hacks 207852940

print("1 4602541")
print("1 5346304")
