# This submission hacks 207411522

print("1 4602541")
print("1 5346304")
