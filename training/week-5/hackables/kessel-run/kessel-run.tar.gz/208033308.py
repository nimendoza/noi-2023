# This submission hacks 208033308

print("1 4602541")
print("1 5346304")
