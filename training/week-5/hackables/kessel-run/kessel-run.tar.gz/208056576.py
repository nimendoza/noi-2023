# This submission hacks 208056576

print("1 4602541")
print("1 5346304")
