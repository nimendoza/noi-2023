# This submission hacks 207813933

print("1 4602541")
print("1 5346304")
