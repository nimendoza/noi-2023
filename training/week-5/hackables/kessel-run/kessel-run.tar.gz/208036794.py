# This submission hacks 208036794

print("1 4602541")
print("1 5346304")
