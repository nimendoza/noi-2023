# This submission hacks 208175020

print("1")
print("2")
print("7 -8")
