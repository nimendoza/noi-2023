# This submission hacks my_solution

print("1")
print("38")
print("-1 1 -6 -10 4 4 9 -2 0 7 -10 -9 1 4 -10 -2 -9 -2 4 2 9 7 1 -9 3 -2 4 9 6 -5 -10 5 -4 3 5 10 -3 -5")
