# This submission hacks 207410015

print("1")
print("2 4625")
print("3464 4463")
print("1509 3271")
