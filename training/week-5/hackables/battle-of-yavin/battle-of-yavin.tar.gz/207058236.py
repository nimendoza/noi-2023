# This submission hacks 207058236

print("1")
print("2 2294")
print("1094 3745")
print("4672 4842")
