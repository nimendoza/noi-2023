# This submission hacks 207149752

print("1")
print("2 2933")
print("947 4143")
print("1734 2368")
