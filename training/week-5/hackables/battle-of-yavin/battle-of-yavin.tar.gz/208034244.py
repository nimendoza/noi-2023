# This submission hacks 208034244

print("1")
print("2 3760")
print("1568 1820")
print("3040 3269")
