# This submission hacks 208122037

print("1")
print("2 3760")
print("1568 1820")
print("3040 3269")
